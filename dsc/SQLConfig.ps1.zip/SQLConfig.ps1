#
# SQLConfig.ps1
#

#
# ConfigureSQLVM.ps1
#
configuration ConfigureSQL {
    param (
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $SqlInstallationISOUri = 'https://automationrgstorage.blob.core.windows.net/iso/en_sql_server_2016_developer_with_service_pack_1_x64_dvd_9548071.iso',

        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $SAStoken = '',
        
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $SQLInstanceName = $ProjectName.Replace('-','_'),

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $ProjectName,
		
        [Parameter()]
        [System.String[]] $Features = ('SQLENGINE'),
        
		[Parameter(Mandatory)]
        [pscredential] $DomainAdminCreds,

        [Parameter()]
        [pscredential] $SetupCredentials = $DomainAdminCreds,
        
        [Parameter()]
        [ValidateSet('Windows','SQL')]
        [System.String] $SecurityMode = 'Windows',
        
        [Parameter()]
        [System.String] $ProductId = [System.String]::Empty,
        
        [Parameter()]
        [Uint16] $Port = 1433,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $DomainFQDN


    )

    $Interface = Get-NetAdapter| Where-Object Name -Like "Ethernet*"| Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

    $NormalizedFeatures = foreach ($F in $Features) {
        $F.ToUpper().Trim()
    }
    $NormalizedFeatures = $NormalizedFeatures -join ','

#    Import-DscResource -ModuleName PSDscResources
	Import-DscResource �ModuleName PSDesiredStateConfiguration
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName SqlServerDsc
    Import-DscResource -ModuleName xNetworking
    Import-DscResource -ModuleName xDownloadISO -ModuleVersion 1.0
	Import-DscResource -ModuleName xActiveDirectory 
#	Import-DscResource -ModuleName xComputerManagement
	Import-DSCResource -ModuleName StorageDSC

	$SQLisoName = $SqlInstallationISOUri.Substring($SqlInstallationISOUri.LastIndexOf('/')+1)
    
    Node localhost {

		File IsoDir {
			Type            = 'Directory'
			DestinationPath = 'C:\iso'
			Ensure          = "Present"    
	    }

		xRemoteFile ISODownload {  
			Uri             = "$SqlInstallationISOUri$SAStoken"
			DestinationPath = "C:\iso\$SQLisoName"
			MatchSource     = $false
			DependsOn = "[File]IsoDir"
	    }

		MountImage ISO
		{
			ImagePath   = "C:\iso\$SQLisoName"
			DriveLetter = 'S'
			DependsOn = "[xRemoteFile]ISODownload"
		}

		WaitForVolume WaitForISO
		{
			DriveLetter      = 'S'
			RetryIntervalSec = 5
			RetryCount       = 10
			DependsOn = "[MountImage]ISO"
		}

		GroupSet AddAdminMemebers
		{
			GroupName = 'Administrators'
			Ensure = 'Present'
			MembersToInclude = "$DomainFQDN\$($SetupCredentials.UserName.Split('@')[0])"
			DependsOn = "[xADUser]SetupCredential"
		}

        WindowsFeature RSATAD
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
        }

		WindowsFeature NetFramework45
		{
			 Name = 'Net-Framework-45-Core'
			 Ensure = 'Present'
		}

		xADUser SetupCredential
		{
				DomainName = $domainFQDN
				DomainAdministratorCredential = $DomainAdminCreds
				UserName = $SetupCredentials.UserName.Split('@')[0]
#				Path = $CRMProjectOU
				Password = New-Object System.Management.Automation.PSCredential ($SetupCredentials.UserName, $SetupCredentials.Password)
				Ensure = "Present"
				DependsOn = "[WindowsFeature]RSATAD"
		}

		xADGroup SQLProjectAdminGroup
		{
			GroupName = "$ProjectName-SQLAdmins"
			DisplayName = "$ProjectName-SQLAdmins"
			Credential = $DomainAdminCreds
			Path = "OU=$ProjectName,OU=CRM,DC=$($domainFQDN.split('.')[0]),DC=$($domainFQDN.split('.')[1])"
			MembersToInclude = $SetupCredentials.UserName.Split('@')[0]
			Ensure = 'Present'
			DependsOn = "[xADUser]SetupCredential"
		}

        Disk SqlDataDisk {
            DiskId = 2
            FSFormat = 'NTFS'
            DriveLetter = 'G'
            FSLabel = 'DataDisk'
        }

        Disk SqlLogDisk {
            DiskId = 3
            FSFormat = 'NTFS'
            DriveLetter = 'I'
            FSLabel = 'Log'
        }

		Disk SqlTempDisk {
            DiskId = 4
            FSFormat = 'NTFS'
            DriveLetter = 'T'
            FSLabel = 'Temp'
        }

		SQLSetup SQLInstall 
		{
				InstanceName         = $SQLInstanceName
				Features             = "SQLENGINE,FULLTEXT"
				SQLCollation         = 'SQL_Latin1_General_CP1_CI_AS'
#				SQLSvcAccount        = "NT Service\MSSQL`$$ProjectName"
#				AgtSvcAccount        = "NT Service\SQLAgent`$$ProjectName"
#				FTSvcAccount         = "NT Service\MSSQLFDLauncher`$$ProjectName"
				SQLSysAdminAccounts  = 'Administrators',"$domainFQDN\$ProjectName-SQLAdmins"
#				InstallSharedDir     = 'C:\Program Files\Microsoft SQL Server'
#				InstallSharedWOWDir  = 'C:\Program Files (x86)\Microsoft SQL Server'
				InstanceDir          = "G:\$ProjectName"
				InstallSQLDataDir     = "G:\$ProjectName"
				SQLUserDBDir = "G:\$ProjectName"
				SQLUserDBLogDir = "I:\$ProjectName"
				SQLTempDBLogDir = "I:\$ProjectName"
				SQLTempDBDir = "T:\$ProjectName"
				BrowserSvcStartupType = 'Automatic'
				SourcePath           = 'S:\'
				UpdateEnabled        = 'False'
				ForceReboot          = $true
				PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($SetupCredentials.UserName.Split('@')[0])", $SetupCredentials.Password)
				DependsOn            = '[WaitForVolume]WaitForISO','[xADGroup]SQLProjectAdminGroup','[WindowsFeature]NetFramework45','[Disk]SqlDataDisk','[Disk]SqlLogDisk','[Disk]SqlTempDisk'
		}

        SQLServerNetwork SQLTCP {
            InstanceName = $SQLInstanceName
            ProtocolName = 'tcp'
            IsEnabled = $true
            TCPPort = $Port
            RestartService = $true
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($SetupCredentials.UserName.Split('@')[0])", $SetupCredentials.Password)
            DependsOn = '[SQLSetup]SQLInstall'
        }
     
        xFirewall SQLTCP {
            Name = 'SQL TCP Allow Inbound'
            Ensure = 'Present'
            Enabled = 'True'
            Action = 'Allow'
            Direction = 'Inbound'
            Profile = 'Domain'
            LocalPort = $Port
            Protocol = 'Tcp'
			DependsOn = '[SQLServerNetwork]SQLTCP'
        }

        xFirewall SQLUDPBrowser {
            Name = 'SQL Browser Port'
            Ensure = 'Present'
            Enabled = 'True'
            Action = 'Allow'
            Direction = 'Inbound'
            Profile = 'Domain'
            LocalPort = '1434'
            Protocol = 'Udp'
			DependsOn = '[SQLServerNetwork]SQLTCP'
        }

		xFirewall FileAndPrinterSharing
		{
            Name                  = 'FPS-SMB-In-TCP'
            Ensure                = 'Present'
            Enabled               = 'True'
		}

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }
    }
}