#
# SecondaryDC.ps1
#
#
# DomainDSC.ps1
#
#$newpasswd = ConvertTo-SecureString "P@ssw0rd" -AsPlainText -Force
#$userCred = New-Object System.Management.Automation.PSCredential ("test.local\NewUser", $newpasswd)
#$users = "dummy","fake"

configuration InstallSDC {
    param (
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $domainFQDN = 'test.local',

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $ProjectName,
		
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $DomainNetBIOS = $domainFQDN.split('.')[0],

        [Parameter(Mandatory)]
        [pscredential] $DomainAdminCreds,
        
        [Parameter()]
        [pscredential] $SafeModeAdminCredentials = $DomainAdminCreds
        
    )
	
	Import-DscResource -ModuleName PsDesiredStateConfiguration
	Import-DscResource -ModuleName xActiveDirectory -ModuleVersion 2.17.0.0

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName)", $DomainAdminCreds.Password)
    [System.Management.Automation.PSCredential ]$SafeModeCreds = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($SafeModeAdminCredentials.UserName)", $SafeModeAdminCredentials.Password)

	Node localhost {

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

	    WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"		
        }

	    WindowsFeature DnsTools
	    {
	        Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
	    }

		WindowsFeature ADDSInstall
		{
			Ensure = "Present"
			Name = "AD-Domain-Services"
			IncludeAllSubFeature = $true
			DependsOn = "[WindowsFeature]DNS"
		}

        WindowsFeature ADDSTools
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

		xWaitForADDomain DscForestWait
		{
			DomainName = $domainFQDN
			DomainUserCredential = $DomainCreds
			RetryCount = 20
			RetryIntervalSec = 30
			DependsOn = "[WindowsFeature]ADDSInstall"
		}
		
        xADDomainController SDC
        {
			DomainName = $domainFQDN
			DomainAdministratorCredential = $DomainCreds
			SafemodeAdministratorPassword = $SafeModeCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

	}
}