#
# CRMConfig.ps1
#

configuration ConfigureCRM {
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $SqlInstallationISOUri = 'https://automationrgstorage.blob.core.windows.net/iso/en_sql_server_2016_developer_with_service_pack_1_x64_dvd_9548071.iso',

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $SAStoken = '',

        
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $SQLInstanceName = $ProjectName.Replace('-','_'),

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $CRMInstallationISOUri,
        
		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $CRMConfigUri,

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $CRMReportingConfigUri = '',

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $ProjectName,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $svcPassword,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String]$SQLserverName = 'sql',
        
		[Parameter(Mandatory)]
        [pscredential] $DomainAdminCreds,

        [Parameter()]
        [pscredential] $SetupCredentials = $DomainAdminCreds,
        
		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $DomainFQDN

    )

#	Import-DscResource �ModuleName PSDesiredStateConfiguration
	Import-DscResource �ModuleName psDSCresources
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName SqlServerDsc 
    Import-DscResource -ModuleName xNetworking 
	Import-DSCResource -ModuleName StorageDSC
	Import-DscResource -ModuleName xActiveDirectory
	Import-DscResource -ModuleName xXMLConfigFile 

	$SQLInstanceName = $ProjectName.Replace('-','_')

	$groups = @(
		($CRMAdminGroupName = "$ProjectName-Administrators"),
		($PrivUserGroupName = "$ProjectName-PrivUserGroup"),
		($SQLAccessGroupName = "$ProjectName-SQLAccessGroup"),
		($ReportingGroupName = "$ProjectName-ReportingGroup"),
		($PrivReportingGroupName = "$ProjectName-PrivReportingGroup")
	)

	$SvcUsers = @(
		($AsyncServiceAccountName = "svc-$ProjectName-Asc"),
		($CrmServiceAccountName = "svc-$ProjectName-Crm"),
		($SandboxServiceAccountName = "svc-$ProjectName-Sbx"),
		($DeploymentServiceAccountName = "svc-$ProjectName-Dpl"),
		($VSSWriterServiceAccountName = "svc-$ProjectName-Vss"),
		($MonitoringServiceAccountName = "svc-$ProjectName-Mon"),
		($RSServiceAccountName = "svc-$ProjectName-Rep")
	)

	$SQLisoName = $SqlInstallationISOUri.Substring($SqlInstallationISOUri.LastIndexOf('/')+1)
	$CRMisoName = $CRMInstallationISOUri.Substring($CRMInstallationISOUri.LastIndexOf('/')+1)
	$CRMconfigName = $CRMConfigUri.Substring($CRMConfigUri.LastIndexOf('/')+1)
	$CRMReportingConfigName = $CRMReportingConfigUri.Substring($CRMReportingConfigUri.LastIndexOf('/')+1)

	$CRMProjectOU = "OU=$ProjectName,OU=CRM,DC=$($domainFQDN.split('.')[0]),DC=$($domainFQDN.split('.')[1])"

    Node localhost {

		WindowsFeature NetFramework45
		{
			 Name = 'Net-Framework-45-Core'
			 Ensure = 'Present'
		}

		Service WindowsIndexSearch
		{
			Name = "WSearch"
			StartupType = "Automatic"
			Ensure = "Present"
		}
		File IsoDir {
			Type            = 'Directory'
			DestinationPath = 'C:\iso'
			Ensure          = "Present"    
	    }

		xRemoteFile ISODownloadCRM 
		{  
			Uri             = "$CRMInstallationISOUri$SAStoken"
			DestinationPath = "C:\iso\$CRMisoName"
			DependsOn       = "[File]IsoDir"
			MatchSource     = $false
	    }
		xRemoteFile ISODownloadSQL 
		{  
			Uri             = "$SqlInstallationISOUri$SAStoken"
			DestinationPath = "C:\iso\$SQLisoName"
			MatchSource     = $false
			DependsOn = "[File]IsoDir"
	    }

		MountImage ISOSQL
		{
			ImagePath   = "C:\iso\$SQLisoName"
			DriveLetter = 'S'
			DependsOn = "[xRemoteFile]ISODownloadSQL"
		}

		xRemoteFile CRMConfigDownload {  
			Uri             = "$CRMConfigUri$SAStoken"
			DestinationPath = "C:\iso\$CRMconfigName"
			DependsOn       = "[File]IsoDir"
			MatchSource     = $false
	    }
 
		WindowsFeature RSATAD
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
        }

		xADOrganizationalUnit CRM
		{
			Name = "CRM"
			Path = "DC=$($domainFQDN.split('.')[0]),DC=$($domainFQDN.split('.')[1])"
			Ensure = "Present"
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
			DependsOn = "[WindowsFeature]RSATAD"
		}

		xADOrganizationalUnit CRMProjectOU
		{
			Name = "$ProjectName"
			Path = "OU=CRM,DC=$($domainFQDN.split('.')[0]),DC=$($domainFQDN.split('.')[1])"
			Ensure = "Present"
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
			DependsOn = "[xADOrganizationalUnit]CRM"
		}

		xADObjectPermissionEntry CRMProjectOU
		{
			Path = "OU=CRM,DC=$($domainFQDN.split('.')[0]),DC=$($domainFQDN.split('.')[1])"
			Ensure = "Present"
			IdentityReference = "$domainFQDN\$($SetupCredentials.UserName.Split('@')[0])"
			AccessControlType = "Allow"
			ActiveDirectoryRights = "GenericAll"
			ActiveDirectorySecurityInheritance = "All"
			ObjectType = "00000000-0000-0000-0000-000000000000"
			InheritedObjectType = "00000000-0000-0000-0000-000000000000"
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
			DependsOn = "[xADOrganizationalUnit]CRMProjectOU","[xADUser]SetupCredentials"
		}
		xADGroup CRMAdminGroup
		{
			Credential = $DomainAdminCreds
			GroupName = $CRMAdminGroupName
			Path = $CRMProjectOU
			MembersToInclude = $SetupCredentials.UserName.Split('@')[0]
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
			DependsOn = "[xADOrganizationalUnit]CRMProjectOU","[xADUser]SetupCredentials"
		}

		xADUser SetupCredentials
		{
				DomainName = $domainFQDN
				DomainAdministratorCredential = $DomainAdminCreds
				UserName = $SetupCredentials.UserName.Split('@')[0]
#				Path = $CRMProjectOU
				Password = New-Object System.Management.Automation.PSCredential ($SetupCredentials.UserName, $SetupCredentials.Password)
				Ensure = "Present"
				PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
				DependsOn = "[WindowsFeature]RSATAD"
		}
		Group AddAdminMemebers
		{
			GroupName = 'Administrators'
			Ensure = 'Present'
			MembersToInclude = "$DomainFQDN\$($SetupCredentials.UserName.Split('@')[0])","$DomainFQDN\$CRMAdminGroupName"
			DependsOn = "[xADUser]SetupCredentials"
		}

		xADGroup PrivUserGroup
		{
			Credential = $DomainAdminCreds
			GroupName = $PrivUserGroupName
			GroupScope = "Universal"
			Path = $CRMProjectOU
			MembersToInclude = "$CRMAdminGroupName"			
			Ensure = "Present"
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
			DependsOn = "[xADGroup]CRMAdminGroup"
		}

		xADGroup SQLAccessGroup
		{
			Credential = $DomainAdminCreds
			GroupName = $SQLAccessGroupName
			GroupScope = "Universal"
			Path = $CRMProjectOU
			Ensure = "Present"
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
			DependsOn = "[xADOrganizationalUnit]CRMProjectOU"
		}

		xADGroup ReportingGroup
		{
			Credential = $DomainAdminCreds
			GroupName = $ReportingGroupName
			GroupScope = "Universal"
			Path = $CRMProjectOU
			Ensure = "Present"
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
			DependsOn = "[xADOrganizationalUnit]CRMProjectOU"
		}
		
		xADGroup PrivReportingGroup
		{
			Credential = $DomainAdminCreds
			GroupName = $PrivReportingGroupName
			GroupScope = "Universal"
			Path = $CRMProjectOU
			Ensure = "Present"
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
			DependsOn = "[xADOrganizationalUnit]CRMProjectOU"
		}

		foreach ($user in $SvcUsers) {
			xADUser "$user"
			{
				DomainName = $domainFQDN
				DomainAdministratorCredential = $DomainAdminCreds
				UserName = $user
				Path = $CRMProjectOU
				Password = New-Object System.Management.Automation.PSCredential ($user,$(ConvertTo-SecureString "$svcPassword" -AsPlainText -Force))
				Ensure = "Present"
				PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$domainFQDN\$($DomainAdminCreds.UserName.Split('@')[0])", $DomainAdminCreds.Password)
				PasswordNeverExpires = $true
				DependsOn = "[xADOrganizationalUnit]CRMProjectOU"
			}
		}

		Group AddPerfLogUsers
		{
			GroupName = 'Performance Log Users'
			Ensure = 'Present'
			MembersToInclude = "$DomainFQDN\$AsyncServiceAccountName","$DomainFQDN\$CrmServiceAccountName"
			DependsOn = "[xADUser]$AsyncServiceAccountName"
		}

		Group AddPerfMonUsers
		{
			GroupName = 'Performance Monitor Users'
			Ensure = 'Present'
			MembersToInclude = "$DomainFQDN\$AsyncServiceAccountName","$DomainFQDN\$CrmServiceAccountName"
			DependsOn = "[xADUser]$AsyncServiceAccountName"
		}

<#		GroupSet AddPerformanceLogUsers
		{
			GroupName = 'Performance Log Users'
			Ensure = 'Present'
			MembersToInclude = "$DomainFQDN\$AsyncServiceAccountName","$DomainFQDN\$CrmServiceAccountName"
			DependsOn = "[xADUser]$AsyncServiceAccountName"
		}#>

		XMLConfigFile PrivGroup
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/Groups'
            Name       = 'PrivUserGroup'
            Value      = "CN=$PrivUserGroupName,$CRMProjectOU"
            isElementTextValue = $true
            Ensure = 'present'
			DependsOn = "[xRemoteFile]CRMConfigDownload"
        }
        
		XMLConfigFile SQLAccessGroup
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/Groups'
            Name       = 'SQLAccessGroup'
            Value      = "CN=$SQLAccessGroupName,$CRMProjectOU"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]PrivGroup"
        }

		XMLConfigFile ReportingGroup
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/Groups'
            Name       = 'ReportingGroup'
            Value      = "CN=$ReportingGroupName,$CRMProjectOU"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]SQLAccessGroup"
        }

		XMLConfigFile PrivReportingGroup
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/Groups'
            Name       = 'PrivReportingGroup'
            Value      = "CN=$PrivReportingGroupName,$CRMProjectOU"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]ReportingGroup"
        }

		XMLConfigFile SQLServer
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server'
            Name       = 'SqlServer'
            Value      = "$SQLserverName.$DomainFQDN\$SQLInstanceName"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]PrivReportingGroup"
        }

		XMLConfigFile ReportingURL
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/Reporting'
            Name       = 'URL'
            Value      = "http://$env:COMPUTERNAME/ReportServer_RSCRM"
            isAttribute = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]SQLServer"
        }

		XMLConfigFile CrmServiceAccountName
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/CrmServiceAccount'
            Name       = 'ServiceAccountLogin'
            Value      = "$($domainFQDN.split('.')[0])\$CrmServiceAccountName"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]ReportingURL"
        }

		XMLConfigFile CrmServiceAccountPassword
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/CrmServiceAccount'
            Name       = 'ServiceAccountPassword'
            Value      = "$svcPassword"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]CrmServiceAccountName"
        }

		XMLConfigFile SandboxServiceAccountName
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/SandboxServiceAccount'
            Name       = 'ServiceAccountLogin'
            Value      = "$($domainFQDN.split('.')[0])\$SandboxServiceAccountName"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]CrmServiceAccountPassword"
        }

		XMLConfigFile SandboxServiceAccountPassword
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/SandboxServiceAccount'
            Name       = 'ServiceAccountPassword'
            Value      = "$svcPassword"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]SandboxServiceAccountName"
        }

		XMLConfigFile DeploymentServiceAccountName
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/DeploymentServiceAccount'
            Name       = 'ServiceAccountLogin'
            Value      = "$($domainFQDN.split('.')[0])\$DeploymentServiceAccountName"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]SandboxServiceAccountPassword"
        }

		XMLConfigFile DeploymentServiceAccountPassword
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/DeploymentServiceAccount'
            Name       = 'ServiceAccountPassword'
            Value      = "$svcPassword"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]DeploymentServiceAccountName"
        }
		
		XMLConfigFile AsyncServiceAccountName
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/AsyncServiceAccount'
            Name       = 'ServiceAccountLogin'
            Value      = "$($domainFQDN.split('.')[0])\$AsyncServiceAccountName"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]DeploymentServiceAccountPassword"
        }

		XMLConfigFile AsyncServiceAccountPassword
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/AsyncServiceAccount'
            Name       = 'ServiceAccountPassword'
            Value      = "$svcPassword"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]AsyncServiceAccountName"
        }

		XMLConfigFile VSSWriterServiceAccountName
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/VSSWriterServiceAccount'
            Name       = 'ServiceAccountLogin'
            Value      = "$($domainFQDN.split('.')[0])\$VSSWriterServiceAccountName"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]AsyncServiceAccountPassword"
        }

		XMLConfigFile VSSWriterServiceAccountPassword
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/VSSWriterServiceAccount'
            Name       = 'ServiceAccountPassword'
            Value      = "$svcPassword"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]VSSWriterServiceAccountName"
        }

		XMLConfigFile MonitoringServiceAccountName
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/MonitoringServiceAccount'
            Name       = 'ServiceAccountLogin'
            Value      = "$($domainFQDN.split('.')[0])\$MonitoringServiceAccountName"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]VSSWriterServiceAccountPassword"
        }

		XMLConfigFile MonitoringServiceAccountPassword
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/MonitoringServiceAccount'
            Name       = 'ServiceAccountPassword'
            Value      = "$svcPassword"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]MonitoringServiceAccountName"
        }

		XMLConfigFile Organization
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server'
            Name       = 'Organization'
            Value      = "$ProjectName"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]MonitoringServiceAccountPassword"
        }

		XMLConfigFile OrganizationUniqueName
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server'
            Name       = 'OrganizationUniqueName'
            Value      = "$ProjectName"
            isElementTextValue = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]Organization"
        }		
#<WebsiteUrl create="true" port="5555"> </WebsiteUrl>
		#XMLConfigFile WebSitePort
		#{
		#	ConfigPath = "C:\iso\$CRMconfigName"
		#	XPath      = '//CRMSetup/Server/WebsiteUrl'
		#	Name       = 'port'
		#	Value      = '443'
		#	isAttribute = $true
		#	Ensure     = 'Present'
		#	DependsOn = "[XMLConfigFile]OrganizationUniqueName"
		#}
#<basecurrency currencyprecision="2" currencysymbol="$" currencyname="Euro" isocurrencycode="EUR"/>
<#		XMLConfigFile basecurrencySymbol
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/basecurrency'
            Name       = 'currencysymbol'
            Value      = '�'
			isAttribute = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]OrganizationUniqueName"
        }
		XMLConfigFile basecurrencyName
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/basecurrency'
            Name       = 'currencyname'
            Value      = 'Euro'
			isAttribute = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]basecurrencySymbol"
        }
		XMLConfigFile basecurrencyCode
        {
            ConfigPath = "C:\iso\$CRMconfigName"
            XPath      = '//CRMSetup/Server/basecurrency'
            Name       = 'isocurrencycode'
            Value      = 'EUR'
			isAttribute = $true
            Ensure     = 'Present'
			DependsOn = "[XMLConfigFile]basecurrencyName"
        }
#>
		SQLSetup RSSQLInstall 
		{
			InstanceName         = "RSCRM"
			Features             = "SQLENGINE,RS"
			RSSvcAccount         = New-Object System.Management.Automation.PSCredential ("$($domainFQDN.split('.')[0])\$RSServiceAccountName", $(ConvertTo-SecureString "$svcPassword" -AsPlainText -Force))
			#"$domainFQDN\$RSServiceAccountName"
			SQLCollation         = 'SQL_Latin1_General_CP1_CI_AS'
			SQLSysAdminAccounts  = 'Administrators',"$($domainFQDN.split('.')[0])\$ProjectName-SQLAdmins"
			SourcePath           = 'S:\'
			UpdateEnabled        = 'False'
			ForceReboot          = $true
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$($domainFQDN.split('.')[0])\$($SetupCredentials.UserName.Split('@')[0])",$SetupCredentials.Password)
			DependsOn            = '[WindowsFeature]NetFramework45','[MountImage]ISOSQL'
		}

		SqlRS DefaultConfiguration
        {
            InstanceName         = 'RSCRM'
            DatabaseServerName   = $env:COMPUTERNAME
            DatabaseInstanceName = 'RSCRM'
			DependsOn = "[SQLSetup]RSSQLInstall"
        }#>

		MountImage ISOCRM
		{
			ImagePath   = "C:\iso\$CRMisoName"
			DriveLetter = 'R'
			DependsOn = "[SqlRS]DefaultConfiguration","[XMLConfigFile]OrganizationUniqueName"
		}

		Package CRMInstall
		{
			Ensure = "Present"
			Name = "Microsoft Dynamics CRM Server 2016"
			Path = "R:\Server\amd64\SetupServer.exe"
			ProductId = '0C524D55-1409-0080-BD7E-530E52560E52'
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$($domainFQDN.split('.')[0])\$($SetupCredentials.UserName.Split('@')[0])", $SetupCredentials.Password)
			Arguments = "/Config C:\iso\$CRMconfigName /Q /L C:\iso\CRMSetup_dsc.log" # args for silent mode
			DependsOn = "[MountImage]ISOCRM"
		}

		if ($CRMReportingConfigUri) {
			xRemoteFile CRMReportingConfigDownload {  
				Uri             = "$CRMReportingConfigUri$SAStoken"
				DestinationPath = "C:\iso\$CRMReportingConfigName"
				DependsOn       = "[Package]CRMInstall"
				MatchSource     = $false
			}
			XMLConfigFile CRMReportingInstanceName
			{
				ConfigPath = "C:\iso\$CRMReportingConfigName"
				XPath      = '//CRMSetup/srsdataconnector'
				Name       = 'instancename'
				Value      = "RSCRM"
				isElementTextValue = $true
				Ensure     = 'Present'
				DependsOn = "[xRemoteFile]CRMReportingConfigDownload"
			}
			XMLConfigFile CRMReportingMonitoringServiceAccountName
			{
				ConfigPath = "C:\iso\$CRMReportingConfigName"
				XPath      = '//CRMSetup/srsdataconnector/MonitoringServiceAccount'
				Name       = 'ServiceAccountLogin'
				Value      = "$($domainFQDN.split('.')[0])\$MonitoringServiceAccountName"
				isElementTextValue = $true
				Ensure     = 'Present'
				DependsOn = "[XMLConfigFile]CRMReportingInstanceName"
			}

			XMLConfigFile CRMReportingMonitoringServiceAccountPassword
			{
				ConfigPath = "C:\iso\$CRMReportingConfigName"
				XPath      = '//CRMSetup/srsdataconnector/MonitoringServiceAccount'
				Name       = 'ServiceAccountPassword'
				Value      = "$svcPassword"
				isElementTextValue = $true
				Ensure     = 'Present'
				DependsOn = "[XMLConfigFile]CRMReportingMonitoringServiceAccountName"
			}
			File ReportManagerDirectory {
				Type = 'Directory'
				DestinationPath = 'C:\Program Files\Microsoft SQL Server\MSRS13.RSCRM\Reporting Services\ReportManager'
				Ensure = "Present"
			}
			File WebConfigCopy
			{
				Ensure = "Present"  # You can also set Ensure to "Absent"
				Type = "File" # Default is "File".
				SourcePath = "C:\Program Files\Microsoft SQL Server\MSRS13.RSCRM\Reporting Services\ReportServer\web.config"
				DestinationPath = "C:\Program Files\Microsoft SQL Server\MSRS13.RSCRM\Reporting Services\ReportManager\web.config"
				DependsOn = "[File]ReportManagerDirectory"
			}
			Package CRMReportingInstall
			{
				Ensure = "Present"
				Name = "Microsoft Dynamics CRM 2016 Reporting Extensions"
				Path = "R:\Server\amd64\SrsDataConnector\SetupSrsDataConnector.exe"
				ProductId = '0C524D71-1409-0080-BFEE-D90853535253'
				PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$($domainFQDN.split('.')[0])\$($SetupCredentials.UserName.Split('@')[0])", $SetupCredentials.Password)
				Arguments = "/Config C:\iso\$CRMReportingConfigName /Q /L C:\iso\CRMReportingSetup_dsc.log" # args for silent mode
				DependsOn = "[XMLConfigFile]CRMReportingMonitoringServiceAccountPassword","[File]WebConfigCopy"
			}
		}

<#        xDisk SqlDataDisk {
            DiskNumber = 2
            FSFormat = 'NTFS'
            DriveLetter = 'G'
            FSLabel = 'SQLData'
        }

        xDisk SqlLogDisk {
            DiskNumber = 3
            FSFormat = 'NTFS'
            DriveLetter = 'I'
            FSLabel = 'SQLLog'
        }#>

        LocalConfigurationManager {
			RebootNodeIfNeeded = $true
        }
    }
}