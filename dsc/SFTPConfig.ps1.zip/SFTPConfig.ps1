#
# SFTPConfig.ps1
#
# !!! authorized_keys file have to be in utf-8 format !!!
#
#
#
#

configuration SftpConfig {
	param (

        [Parameter()]
        [System.Object[]] $SFTPUsers = @([Hashtable]@{"name" = "sftp01";"PubkeyAuthentication"="yes";"PasswordAuthentication"="no";"key"=''}),
               
		[Parameter(Mandatory)]
        [pscredential] $DomainAdminCreds,

        [Parameter()]
        [pscredential] $SetupCredentials = $DomainAdminCreds,
        
		[Parameter(Mandatory)]
        [System.String] $SftpUserPassword,

        [Parameter()]
        [Uint16] $SFTPPort = 22,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $DomainFQDN,

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $windowsCapabilityName = 'OpenSSH.Server~~~~0.0.1.0',

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String]$sqlServer = 'swq-sql-01'

    )

	#Import necessary modules
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
	Import-DscResource -ModuleName AccessControlDSC
	Import-DscResource -ModuleName xSmbShare

	$path_sshd_config = 'C:\ProgramData\ssh\sshd_config'
	$SFTPPath = 'c:\sftp'

	$keyAuthorizationFile = 'C:\ProgramData\ssh\authorized_keys'

	#Configure node
	Node localhost 
	{
		Script InstallWindowsCapability
		{
			GetScript = {
				$windowsCapability = get-WindowsCapability -Online -Name $using:windowsCapabilityName
				return @{Result = $windowsCapability.State}
			}
			TestScript = {
				if ((get-WindowsCapability -Online -Name $using:windowsCapabilityName).state -eq 'Installed') {Return $true} else {Return $false}
			}
			SetScript = {
				try {
					Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
					Set-Service sshd -StartupType Automatic
					Set-Service ssh-agent -StartupType Automatic
					Start-Service sshd
					Start-Service ssh-agent
				} catch {
					Write-Output "OpenSSH Server cannot be installed"
				}
			}
		}

        Script SetSFTPUsersInConfig            
        {            
            # Must return a hashtable with at least one key            
            # named 'Result' of type String            
            GetScript = {   
                Return @{            
                    Result = {
						#set index of matching user string to 0
						$matchindex = 0
						#get sshd config content
						$sshd_config = Get-Content $using:path_sshd_config
						for ($i=0;$i -le $sshd_config.Count;$i++) {
							#if sshd conteins the enabled users, then get configuration for them
							if ($sshd_config[$i] -like "Match user *") {
								$matchindex = $i
								$sshd_config[$i]
								for ($i=$matchindex+1;$i -le $sshd_config.Count;$i++) {
									if ($sshd_config[$i] -like "*Match user*" -or $sshd_config[$i] -match '^\z*\s*$') {break } else {
										switch -regex ($sshd_config[$i]) {
											'^\z*\s*ChrootDirectory\s+(?<path>[a-z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]*)\s*$'{$_};
											'^\z*\s*PubkeyAuthentication\s+(?<value>\w+)\s*$'{$_};
											'^\z*\s*PasswordAuthentication\s+(?<value>\w+)\s*$'{$_};
											'^\z*\s*AuthorizedKeysFile\s+(?<value>\w+)\s*$'{$_};
											'^\z*\s*ForceCommand\s+(?<value>.*)\s*$'{$_};
											default{"not recoqnized paramater: $_"}
										}
									}
								}
							} elseif ($i -ge $sshd_config.Count -and $matchindex -eq '0') {
									"The are no users enabled in the sshd_config"
							}
						}
					}            
                }            
            }            
            
            # Must return a boolean: $true or $false            
            TestScript = {            
				$matchUsersConfig = $true
				#check if provided user configuration is equal to the configuration in config
				foreach ($SFTPUser in $using:SFTPUsers) {
					$userinsshdconfig = $false
					#get sshd config content
					$sshd_config = Get-Content $using:path_sshd_config
					for ($i=0;$i -le $sshd_config.Count;$i++) {
						#if sshd contains the user defenitions
						if ($sshd_config[$i] -match "^\z*\s*Match user\s+(?<name>[a-zA-Z_\-0-9]*)\s*$")  {
							if ($matches.name -eq $SFTPUser.name) {
								$userinsshdconfig = $true
								#"Test if user $($SFTPUser.name) is configured correctly"
								for ($i=$i+1;$i -le $sshd_config.Count;$i++) {
									if ($sshd_config[$i] -like "*Match user*" -or $sshd_config[$i] -match '^\z*\s*$') {break } else {
										switch -regex ($sshd_config[$i]) {
											'^\z*\s*ChrootDirectory\s+(?<path>[a-z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]*)\s*$'{
													#"$($matches.path)"
													if ($SFTPUser.path) {
														if ($matches.path -ne $SFTPUser.path) {$matchUsersConfig = $false}
													} else {
														if ($matches.path -ne "$using:SFTPPath\$($SFTPUser.name)") {$matchUsersConfig = $false}
													}
												};
											'^\z*\s*PubkeyAuthentication\s+(?<value>\w+)\s*$'{
												#"$($matches.value)"
												if ($matches.value -ne $SFTPUser.PubkeyAuthentication) {$matchUsersConfig = $false}
											};
											'^\z*\s*PasswordAuthentication\s+(?<value>\w+)\s*$'{
												#"$($matches.value)"
												if ($matches.value -ne $SFTPUser.PasswordAuthentication) {$matchUsersConfig = $false}
											};
											'^\z*\s*AuthorizedKeysFile\s+(?<value>\w+)\s*$'{
												#"$($matches.value)"
												if ($matches.value -ne $SFTPUser.Key) {$matchUsersConfig = $false}
											};
                                            '^\z*\s*ForceCommand\s+(?<value>.*)\s*$'{
                                                #"$($matches.value)"
                                            };
											default {$matchUsersConfig = $false}
										}
									}
								}
							} else {
								$userinDSCconfig = $false
								$using:SFTPUsers | % {if ($_.name -eq $matches.name) {$userinDSCconfig = $true}}
								#"Test if user $($matches.name) is in the DSC config: $userinDSCconfig"
								$matchUsersConfig = $matchUsersConfig -and $userinDSCconfig
							}
						} elseif ($i -ge $sshd_config.Count -and $userinsshdconfig -eq $false) {
							#"User $($SFTPUser.name) not exists in the sshd config"
							$matchUsersConfig = $false
						} 
					}
				}
				Return $matchUsersConfig
            }            
            
            # Returns nothing            
            SetScript = {            
				#get sshd config content
				$sshd_config = Get-Content $using:path_sshd_config
				$new_sshd_config = [string[]]@()
				for ($i=0;$i -le $sshd_config.Count;$i++) {
					#if sshd conteins the enabled users, then remove them from configuration
					if ($sshd_config[$i] -like "Match user *") {
						for ($i=$i+1;$i -le $sshd_config.Count;$i++) {
							if ($sshd_config[$i] -like "*Match user*" -or $sshd_config[$i] -match '^\z*\s*$') {break}
						}
					} elseif ($i -ge $sshd_config.Count -and $matchindex -eq '0') {
						Write-Verbose "The are no users enabled in the sshd_config"
					} else {
						#copy string from the old config to the new config
						$new_sshd_config += $sshd_config[$i]
					}
				}
				foreach ($SFTPUser in $using:SFTPUsers) {
					$userconfig = @"
Match user $($SFTPUser.name)
ChrootDirectory $(if ($SFTPUser.path) {$SFTPUser.path} else {"$using:SFTPPath\$($SFTPUser.name)"})
PubkeyAuthentication $($SFTPUser.PubkeyAuthentication)
PasswordAuthentication $($SFTPUser.PasswordAuthentication)
ForceCommand internal-sftp
AuthorizedKeysFile $SFTPPath\.ssh\$($sftpUser.name)_authorized_key

"@
					$new_sshd_config += $userconfig
				}
				#Set new configuration content
				$new_sshd_config | set-Content $using:path_sshd_config -Encoding UTF8
				restart-service sshd
            }
			DependsOn = "[Script]InstallWindowsCapability"
        }         

		File SftpDir 
		{
			Type            = 'Directory'
			DestinationPath = $SFTPPath
			Ensure          = 'Present'
			DependsOn = "[Script]SetSFTPUsersInConfig"
	    }
		xSmbShare SftpSMBShare
        {
            Ensure = "Present"
            Name   = "sftp"
            Path = "$SFTPPath"
            Description = "This is a sftp SMB Share"
			FullAccess = "$DomainFQDN\$sqlServer$"
			DependsOn = "[File]SftpDir"
        }

		File SftpSSHDir
		{
			Type            = 'Directory'
			DestinationPath = "$SFTPPath\.ssh"
			Ensure          = 'Present'
			DependsOn = "[Script]SetSFTPUsersInConfig"
	    }

		NTFSAccessEntry "authorized_key-dir-access"
		{
			Path = "$SFTPPath\.ssh"
			Force = $true
			AccessControlList = @(
				NTFSAccessControlList
				{
					Principal = "NT AUTHORITY\SYSTEM"
					ForcePrincipal = $true
					AccessControlEntry = @(
						NTFSAccessControlEntry
						{
							AccessControlType = 'Allow'
							FileSystemRights = 'FullControl'
							Inheritance = 'This folder subfolders and files'
							Ensure = 'Present'
						}
					)               
				}
				NTFSAccessControlList
				{
					Principal = "BUILTIN\Administrators"
					ForcePrincipal = $false
					AccessControlEntry = @(
						NTFSAccessControlEntry
						{
							AccessControlType = 'Allow'
							FileSystemRights = 'FullControl'
							Inheritance = 'This folder subfolders and files'
							Ensure = 'Present'
						}
					)               
				}
			)
			DependsOn = "[File]SftpSSHDir"
		}
		foreach ($sftpUser in $SFTPUsers) {

			User "$($sftpUser.name)" {
				UserName = "$($sftpUser.name)"
				Disabled = $False
				Ensure = "Present"
				Password = New-Object System.Management.Automation.PSCredential ($sftpUser.name,$(ConvertTo-SecureString "$SftpUserPassword" -AsPlainText -Force)) 
			}

			File "$($sftpUser.name)Dir" 
			{
				Type            = 'Directory'
				DestinationPath = "$SFTPPath\$($sftpUser.name)"
				Ensure          = 'Present' 
				DependsOn = "[File]SftpDir"
			}

			File "$($sftpUser.name)_authorized_key" 
			{
				Type            = 'File'
				DestinationPath = "$SFTPPath\.ssh\$($sftpUser.name)_authorized_key"
				Ensure          = 'Present' 
				Contents = "$($sftpUser.key)"
				DependsOn = "[File]$($sftpUser.name)Dir"
			}

			NTFSAccessEntry "$($sftpUser.name)Dir-access"
			{
				Path = "$SFTPPath\$($sftpUser.name)"
				AccessControlList = @(
					NTFSAccessControlList
					{
						Principal = "$($sftpUser.name)"
						ForcePrincipal = $false
						AccessControlEntry = @(
							NTFSAccessControlEntry
							{
								AccessControlType = 'Allow'
								FileSystemRights = 'FullControl'
								Inheritance = 'This folder and files'
								Ensure = 'Present'
							}
						)               
					}
					NTFSAccessControlList
					{
						Principal = "$DomainFQDN\$sqlServer$"
						ForcePrincipal = $false
						AccessControlEntry = @(
							NTFSAccessControlEntry
							{
								AccessControlType = 'Allow'
								FileSystemRights = 'FullControl'
								Inheritance = 'This folder and files'
								Ensure = 'Present'
							}
						)               
					}
				)
				DependsOn = "[File]$($sftpUser.name)Dir"
			}
		}
	}
}