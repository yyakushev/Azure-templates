#
# Dox42Config.ps1
#

configuration Dox42Config {
	param (
		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $Dox42lInstallationPackageUri = 'https://storageszbprywnptdce.blob.core.windows.net/packages/dox42ServerPackV4120.zip',

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $CertificateUri = 'https://storageszbprywnptdce.blob.core.windows.net/certificates/onitvt.pfx?sp=r&st=2018-12-12T15:55:36Z&se=2018-12-30T23:55:36Z&spr=https&sv=2018-03-28&sig=98xueEYbOd9gEaHq5BvBsQuU4dpezPQ1T86T0ocoe%2Fw%3D&sr=b',

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $CertificateThumbprint,

		[Parameter(Mandatory = $false)]
        [pscredential]  $CertificatePassword,

        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $SAStoken = '',
                
		[Parameter(Mandatory)]
        [pscredential] $DomainAdminCreds,

        [Parameter()]
        [pscredential] $SetupCredentials = $DomainAdminCreds,
        
        [Parameter()]
        [Uint16] $Port = 8443,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $DomainFQDN

    )
	#Import necessary modules
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
	Import-DscResource -ModuleName CertificateDsc
	Import-DscResource -ModuleName xWebAdministration

	$Dox42PackageName = $Dox42lInstallationPackageUri.Substring($Dox42lInstallationPackageUri.LastIndexOf('/')+1)
	$Dox42webDirectory = 'c:\dox42server'
	$packageDirectory = 'c:\Packages'

	#Configure node
	Node localhost 
	{

		File PackageDir 
		{
			Type            = 'Directory'
			DestinationPath = $packageDirectory
			Ensure          = "Present"    
	    }

		xRemoteFile Dox42PackageDownload 
		{  
			Uri             = "$Dox42lInstallationPackageUri$SAStoken"
			DestinationPath = "$packageDirectory\$Dox42PackageName"
			MatchSource     = $false
			DependsOn = "[File]PackageDir"
	    }
		
		xWindowsFeatureSet Dox42WindowsFeaturesSet
        {
            Ensure = "Present"
            Name = @('Web-Server', 'NET-Framework-45-ASPNET','Web-Common-Http','Web-Mgmt-Tools','Web-Asp-Net','Web-Asp-Net45')
        }

        Archive Dox42ExpandPackage
        {
            Path = "$packageDirectory\$Dox42PackageName"
            Destination = $packageDirectory
            Ensure = 'Present'
			DependsOn = "[xRemoteFile]Dox42PackageDownload"
        }

		File Dox42CopyToWebDir
		{
			DestinationPath = "$Dox42webDirectory"
			SourcePath = "$packageDirectory\$($Dox42PackageName.replace('.zip',''))\$($Dox42PackageName.replace('.zip','').replace('Pack',''))\dox42Server"
			Ensure = 'Present'
			Recurse = $true
			Type = 'Directory'
			DependsOn = "[Archive]Dox42ExpandPackage"
		}

		xWebsite DefaultSite 
        {
            Ensure          = 'Present'
            Name            = 'Default Web Site'
            State           = 'Stopped'
			DependsOn = "[xWindowsFeatureSet]Dox42WindowsFeaturesSet"
        }

        PfxImport webCertificate
        {
            Thumbprint = $CertificateThumbprint
            Path       = $CertificateUri
            Location   = 'LocalMachine'
            Store      = 'WebHosting'
            Credential = $CertificatePassword
            DependsOn  = '[xWindowsFeatureSet]Dox42WindowsFeaturesSet'
        }

		xWebAppPool dox42AppPool
		{
			Name = 'dox42Server'
			pingResponseTime = (New-TimeSpan -Seconds 1000).ToString()
			loadUserProfile = $true
			Ensure = 'Present'
			DependsOn = "[xWebsite]DefaultSite"
		}
		xWebsite dox42Server
		{
			Ensure = 'Present'
			Name = 'dox42Server'
			ApplicationPool = 'dox42Server'
			State = 'Started'
			PhysicalPath = "$Dox42webDirectory"
			BindingInfo = MSFT_xWebBindingInformation
			{
				Port = 443
				HostName = "dox42-sw365-qa.onitvt.com" 
				Protocol = "https"
				CertificateThumbprint = $CertificateThumbprint
				CertificateStoreName = 'WebHosting'
			}
			DependsOn = "[xWebAppPool]dox42AppPool", "[PfxImport]webCertificate"
		}
	}
}