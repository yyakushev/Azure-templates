#
# Dox42Config.ps1
#

configuration Dox42Config {
	param (
		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $Dox42lInstallationPackageUri = 'https://storageszbprywnptdce.blob.core.windows.net/packages/dox42ServerPackV4120.zip',

        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $SAStoken = '',
                
		[Parameter(Mandatory)]
        [pscredential] $DomainAdminCreds,

        [Parameter()]
        [pscredential] $SetupCredentials = $DomainAdminCreds,
        
        [Parameter()]
        [Uint16] $Port = 8443,

		[Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [System.String] $DomainFQDN

    )
	#Import necessary modules
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
	Import-DscResource -ModuleName xCertificate

	$Dox42PackageName = $Dox42lInstallationPackageUri.Substring($Dox42lInstallationPackageUri.LastIndexOf('/')+1)
	$Dox42webDirectory = 'c:\dox42server'
	$packageDirectory = 'c:\Packages'

	#Configure node
	Node localhost 
	{

		File PackageDir 
		{
			Type            = 'Directory'
			DestinationPath = $packageDirectory
			Ensure          = "Present"    
	    }

		xRemoteFile Dox42PackageDownload 
		{  
			Uri             = "$Dox42lInstallationPackageUri$SAStoken"
			DestinationPath = "$packageDirectory\$Dox42PackageName"
			MatchSource     = $false
			DependsOn = "[File]PackageDir"
	    }
		
		Install-WindowsFeature -Name Web-Server, NET-Framework-45-ASPNET,Web-Common-Http,Web-Mgmt-Tools,Web-Asp-Net,Web-Asp-Net45

		xWindowsFeatureSet Dox42WindowsFeaturesSet
        {
            Ensure = "Present"
            Name = @('Web-Server', 'NET-Framework-45-ASPNET','Web-Common-Http','Web-Mgmt-Tools','Web-Asp-Net','Web-Asp-Net45')
        }

        Archive Dox42ExpandPackage
        {
            Path = "$packageDirectory\$Dox42PackageName"
            Destination = "$packageDirectory"
            Ensure = 'Present'
			DependsOn = "[xRemoteFile]Dox42PackageDownload"
        }

		File Dox42CopyToWebDir
		{
			DestinationPath = $Dox42webDirectory
			SourcePath = "$packageDirectory\$($Dox42PackageName.replace('.zip',''))\$($Dox42PackageName.replace('.zip','').replace('Pack',''))"
			Ensure = 'Present'
			Recurse = $true
			Type = 'Directory'
			DependsOn = "[Archive]Dox42ExpandPackage"
		}
	}
}