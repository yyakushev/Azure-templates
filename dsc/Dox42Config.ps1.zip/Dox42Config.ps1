#
# Dox42Config.ps1
#
# Have to be done:
# 1. Create share templates share for dox42release user 
# 2. Enable ports in firewall  for robocopy 137,138,139 and 445
# 3. Copy "dox42 Dynamics CRM" libraries to the webdox42\bin

configuration Dox42Config {
	param (
	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[System.String] $Dox42lInstallationPackageUri = 'https://storageszbprywnptdce.blob.core.windows.net/packages/dox42ServerPackV4120.zip',

	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[System.String] $CertificateUri = 'https://storageszbprywnptdce.blob.core.windows.net/certificates/onitvt.pfx?sp=r&st=2018-12-12T15:55:36Z&se=2018-12-30T23:55:36Z&spr=https&sv=2018-03-28&sig=98xueEYbOd9gEaHq5BvBsQuU4dpezPQ1T86T0ocoe%2Fw%3D&sr=b',

	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[System.String] $CertificateThumbprint,

	[Parameter(Mandatory = $false)]
	[pscredential]  $CertificatePassword,

	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[System.String] $SAStoken = '',
                
	[Parameter(Mandatory)]
	[pscredential] $DomainAdminCreds,

	[Parameter(Mandatory)]
	[pscredential] $Dox42releaseUser,

	[Parameter()]
	[system.string] $licenseKey = 'fa203d86-b6df-410e-9c6f-84429cd61dd8',

	[Parameter()]
	[system.string] $dox42CRMLicenseKey = '9c322376-f25e-4b99-bb29-3669ec365993',
	
	[Parameter()]
	[pscredential] $SetupCredentials = $DomainAdminCreds,
        
	[Parameter()]
	[Uint16] $dox42webport = 443,

	[Parameter(Mandatory)]
	[ValidateNotNullOrEmpty()]
	[System.String] $DomainFQDN

    )
	#Import necessary modules
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
	Import-DscResource -ModuleName CertificateDsc
	Import-DscResource -ModuleName xWebAdministration
	Import-DscResource -ModuleName AccessControlDSC

	$Dox42PackageName = $Dox42lInstallationPackageUri.Substring($Dox42lInstallationPackageUri.LastIndexOf('/')+1)
	$Dox42webDirectory = 'c:\dox42server'
	$packageDirectory = 'c:\Packages'
	$tempDirectory = "$Dox42webDirectory\WorkingDir"

	#Configure node
	Node localhost 
	{
		user Dox42ReleaseUser 
		{
			UserName = $Dox42releaseUser.username
			Ensure = "Present"
			Disabled = $False
			Password = New-Object System.Management.Automation.PSCredential ($Dox42releaseUser.username,$Dox42ReleaseUser.password)
		}

		NTFSAccessEntry "$($Dox42releaseUser.name)-TemplateDir"
		{
			Path = "$Dox42webDirectory\templates"
			AccessControlList = @(
				NTFSAccessControlList
				{
					Principal = "$($Dox42releaseUser.name)"
					ForcePrincipal = $false
					AccessControlEntry = @(
						NTFSAccessControlEntry
						{
							AccessControlType = 'Allow'
							FileSystemRights = 'FullControl'
							Inheritance = 'This folder and files'
							Ensure = 'Present'
						}
					)               
				}
			)
			DependsOn = "[xWebsite]dox42Server", "[user]Dox42ReleaseUser"
		}

		File PackageDir 
		{
			Type            = 'Directory'
			DestinationPath = $packageDirectory
			Ensure          = "Present"    
	    }

		xRemoteFile Dox42PackageDownload 
		{  
			Uri             = "$Dox42lInstallationPackageUri$SAStoken"
			DestinationPath = "$packageDirectory\$Dox42PackageName"
			MatchSource     = $false
			DependsOn = "[File]PackageDir"
	    }
		
		xWindowsFeatureSet Dox42WindowsFeaturesSet
        {
            Ensure = "Present"
            Name = @('Web-Server', 'NET-Framework-45-ASPNET','Web-Common-Http','Web-Mgmt-Tools','Web-Asp-Net','Web-Asp-Net45')
        }

        Archive Dox42ExpandPackage
        {
            Path = "$packageDirectory\$Dox42PackageName"
            Destination = $packageDirectory
            Ensure = 'Present'
			DependsOn = "[xRemoteFile]Dox42PackageDownload"
        }

		File Dox42CopyToWebDir
		{
			DestinationPath = "$Dox42webDirectory"
			SourcePath = "$packageDirectory\$($Dox42PackageName.replace('.zip',''))\$($Dox42PackageName.replace('.zip','').replace('Pack',''))\dox42Server"
			Ensure = 'Present'
			Recurse = $true
			Type = 'Directory'
			DependsOn = "[Archive]Dox42ExpandPackage"
		}

		xWebsite DefaultSite 
        {
            Ensure          = 'Present'
            Name            = 'Default Web Site'
            State           = 'Stopped'
			DependsOn = "[xWindowsFeatureSet]Dox42WindowsFeaturesSet"
        }

		xRemoteFile webCertificateDownload 
		{  
			Uri             = $CertificateUri
			DestinationPath = "$packageDirectory\cert.pfx"
			MatchSource     = $false
			DependsOn = "[File]PackageDir"
	    }

        PfxImport webCertificate
        {
            Thumbprint = $CertificateThumbprint
            Path       = "$packageDirectory\cert.pfx"
            Location   = 'LocalMachine'
            Store      = 'WebHosting'
            Credential = $CertificatePassword
            DependsOn  = '[xWindowsFeatureSet]Dox42WindowsFeaturesSet'
        }

		xWebAppPool dox42AppPool
		{
			Name = 'dox42Server'
			pingResponseTime = (New-TimeSpan -Seconds 1000).ToString()
			loadUserProfile = $true
			Ensure = 'Present'
			DependsOn = "[xWebsite]DefaultSite"
		}
		xWebsite dox42Server
		{
			Ensure = 'Present'
			Name = 'dox42Server'
			ApplicationPool = 'dox42Server'
			State = 'Started'
			PhysicalPath = "$Dox42webDirectory"
			BindingInfo = MSFT_xWebBindingInformation
			{
				Port = $dox42webport
				HostName = "dox42-sw365-qa.onitvt.com" 
				Protocol = "https"
				CertificateThumbprint = $CertificateThumbprint
				CertificateStoreName = 'WebHosting'
			}
			DependsOn = "[xWebAppPool]dox42AppPool", "[PfxImport]webCertificate"
		}

        xWebConfigKeyValue LiecenseKey 
        {
            Ensure          = 'Present'
            ConfigSection   = 'AppSettings'
            Key             = 'LicenseKey'
            Value           = $licenseKey
            WebsitePath     = 'IIS:\Sites\' + 'dox42Server'
			DependsOn = "[xWebsite]dox42Server"
        }
		
		xWebConfigKeyValue dox42CRMLicenseKey 
        {
            Ensure          = 'Present'
            ConfigSection   = 'AppSettings'
            Key             = 'dox42CRMLicenseKey'
            Value           = $dox42CRMLicenseKey
            WebsitePath     = 'IIS:\Sites\' + 'dox42Server'
			DependsOn = "[xWebConfigKeyValue]LiecenseKey"
        }


		xWebConfigKeyValue TemplateFolder 
        {
            Ensure          = 'Present'
            ConfigSection   = 'trustedTemplateLocations'
            Key             = 'local'
            Value           = "$Dox42webDirectory\templates"
            WebsitePath     = 'IIS:\Sites\' + 'dox42Server'
			DependsOn = "[xWebConfigKeyValue]dox42CRMLicenseKey"
        }

		xWebConfigKeyValue CRMDataEngine
		{
            Ensure          = 'Present'
            ConfigSection   = 'AppSettings'
            Key             = 'CRMDataEngine.CRMDataSourceParser'
            Value           = "CRM Data Source;$Dox42webDirectory\bin\CRMDataEngine.dll;"
            WebsitePath     = 'IIS:\Sites\' + 'dox42Server'
			DependsOn = "[xWebConfigKeyValue]TemplateFolder"
        }
	}
}