# Description

The resource is used to import a PFX certificate into a Windows certificate
store.
