configuration Dox42Config {
	param (
		[Parameter()]
		[ValidateNotNullOrEmpty()]
		[System.String] $SSISInstallationPackageUri = '',

		[Parameter()]
		[ValidateNotNullOrEmpty()]
		[System.String] $SherpaDataMoverPackageUri = '',

		[Parameter()]
		[ValidateNotNullOrEmpty()]
		[System.String] $KingswaysoftInstallationPackageUri = '',

		[Parameter()]
		[ValidateNotNullOrEmpty()]
		[System.String] $DACPACPackageUri = '',

		[Parameter()]
		[ValidateNotNullOrEmpty()]
		[System.String] $SAStoken = '',
                
		[Parameter(Mandatory)]
		[pscredential] $DomainAdminCreds,

		[Parameter()]
		[pscredential] $SetupCredentials = $DomainAdminCreds,
        
		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[System.String] $DomainFQDN,

		[Parameter(Mandatory)]
		[pscredential] $vstsPATToken,

		[Parameter(Mandatory)]
		[System.String] $vstsServerUrl,

		[Parameter()]
		[System.String] $vstscollectionname,
	
		[Parameter()]
		[System.String] $vstsprojectname,
			
		[Parameter()]
		[System.String] $vstswork,

		[Parameter()]
		[System.String] $vstsdeploymentgroupname,
		
		[Parameter()]
		[System.String] $vstsdeploymentGroupTags,

		[Parameter()]
		[System.String] $vstsAgentDirectory = 'c:\vstsagents'

    )
	$packageDirectory = 'c:\Packages'
	$SSISPackageName = $SSISInstallationPackageUri.Substring($SSISInstallationPackageUri.LastIndexOf('/')+1)
	$KingswaysoftPackageName = $KingswaysoftInstallationPackageUri.Substring($KingswaysoftInstallationPackageUri.LastIndexOf('/')+1)
	$SherpaDataMoverPackageName = $SherpaDataMoverPackageUri.Substring($SherpaDataMoverPackageUri.LastIndexOf('/')+1)
	
	#Import necessary modules
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
	Import-DscResource -ModuleName AccessControlDSC
	Import-DscResource -ModuleName VSTSAgent

	Node localhost 
	{	
		File PackageDir 
		{
			Type            = 'Directory'
			DestinationPath = $packageDirectory
			Ensure          = "Present"    
	    }

		xRemoteFile SSISPackageDownload 
		{  
			Uri             = "$SSISInstallationPackageUri$SAStoken"
			DestinationPath = "$packageDirectory\$SSISPackageName"
			MatchSource     = $false
			DependsOn = "[File]PackageDir"
	    }
		
		xRemoteFile SherpaDataMoverPackageDownload 
		{  
			Uri             = "$SherpaDataMoverPackageUri$SAStoken"
			DestinationPath = "$packageDirectory\$SherpaDataMoverPackageName"
			MatchSource     = $false
			DependsOn = "[File]PackageDir"
	    }

		Archive SherpaDataMoverExpandPackage
        {
            Path = "$packageDirectory\$SherpaDataMoverPackageName"
            Destination = 'C:\ITVT.SW365.SherpaDataMover'
            Ensure = 'Present'
			DependsOn = "[xRemoteFile]SherpaDataMoverPackageDownload"
        }

		xRemoteFile KingswaysoftPackageDownload 
		{  
			Uri             = "$KingswaysoftInstallationPackageUri$SAStoken"
			DestinationPath = "$packageDirectory\$KingswaysoftPackageName"
			MatchSource     = $false
			DependsOn = "[File]PackageDir"
	    }

        Archive KingswaysoftExpandPackage
        {
            Path = "$packageDirectory\$KingswaysoftPackageName"
            Destination = $packageDirectory
            Ensure = 'Present'
			DependsOn = "[xRemoteFile]KingswaysoftPackageDownload"
        }

		Package KingswaysoftInstall
		{
			Ensure = "Present"
			Name = "SSIS Integration Toolkit for Microsoft Dynamics 365 (64-bit)"
			Path = "$packageDirectory\IntegrationToolkit-Dynamics365-x64.msi"
			ProductId = '02ACC956-144B-4494-9EEE-B4068A142623'
			PsDscRunAsCredential = New-Object System.Management.Automation.PSCredential ("$($domainFQDN.split('.')[0])\$($SetupCredentials.UserName.Split('@')[0])", $SetupCredentials.Password)
			Arguments = "/quiet" # args for silent mode
			DependsOn = "[Archive]KingswaysoftExpandPackage"
		}

		xVSTSAgent VSTSAgent {
			Name                = $env:COMPUTERNAME
			ServerUrl           = $vstsServerUrl		
			PATToken            = $vstsPATToken
			collectionname      = $vstscollectionname
			projectname         = $vstsprojectname
			deploymentgroupname = $vstsdeploymentgroupname
			deploymentGroupTags = $vstsdeploymentGroupTags
			AgentDirectory      = $vstsAgentDirectory
			Work                = $vstsWork
			Ensure              = 'Present'
		}
	}

}