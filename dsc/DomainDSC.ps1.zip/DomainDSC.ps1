#
# DomainDSC.ps1
#
#$newpasswd = ConvertTo-SecureString "P@ssw0rd" -AsPlainText -Force
#$userCred = New-Object System.Management.Automation.PSCredential ("test.local\NewUser", $newpasswd)
#$users = "dummy","fake"

configuration ConfigurePDC {
    param (
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $domainFQDN = 'test.local',

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $ProjectName,
		
        [Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $DomainNetBIOS = $domainFQDN.split('.')[0],

		[Parameter()]
        [ValidateNotNullOrEmpty()]
        [System.String] $PrivateIP,

        [Parameter(Mandatory)]
        [pscredential] $AdminCreds,
        
        [Parameter()]
        [pscredential] $SafeModeAdminCredentials = $AdminCreds
        
    )
	
	Import-DscResource -ModuleName PsDesiredStateConfiguration
	Import-DscResource -ModuleName xActiveDirectory -ModuleVersion 2.17.0.0

	Node localhost {

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

		WindowsFeature ADDSInstall
		{
			Ensure = "Present"
			Name = "AD-Domain-Services"
			IncludeAllSubFeature = $True
		}
		xADDomain PDC
		{
			DomainName = $domainFQDN
			DomainAdministratorCredential = $AdminCreds
			SafemodeAdministratorPassword = $SafeModeAdminCredentials
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		xWaitForADDomain DscForestWait
		{
			DomainName = $domainFQDN
			DomainUserCredential = $AdminCreds
			RetryCount = 20
			RetryIntervalSec = 30
			DependsOn = "[xADDomain]PDC"
		}

		xADOrganizationalUnit CRM
		{
			Name = "CRM"
			Path = "DC=$($domainFQDN.split('.')[0]),DC=$($domainFQDN.split('.')[1])"
			Ensure = "Present"
			DependsOn = "[xWaitForADDomain]DscForestWait"
		}

		xADOrganizationalUnit CRMProjectOU
		{
			Name = "$ProjectName"
			Path = "OU=CRM,DC=$($domainFQDN.split('.')[0]),DC=$($domainFQDN.split('.')[1])"
			Ensure = "Present"
			DependsOn = "[xADOrganizationalUnit]CRM"
		}
<#		foreach ($user in $users) {
			xADUser "$user"
			{
				DomainName = $domainFQDN
				DomainAdministratorCredential = $domaincred
				UserName = $user
				Password = New-Object System.Management.Automation.PSCredential ($user, $(ConvertTo-SecureString "!qa2ws3ed4rf5tg6yh" -AsPlainText -Force))
				Ensure = "Present"
				DependsOn = "[xADOrganizationalUnit]DummyOU"
			}
		}

		Write-Verbose -Verbose "$user added to group DummyGroup"#>
	}
}