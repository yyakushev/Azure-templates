configuration MakoConfig {
	param (

		[Parameter(Mandatory)]
		[pscredential] $vstsPATToken,

		[Parameter(Mandatory)]
		[System.String] $vstsServerUrl,

		[Parameter()]
		[System.String] $vstscollectionname,
	
		[Parameter()]
		[System.String] $vstsprojectname,
			
		[Parameter()]
		[System.String] $vstswork,

		[Parameter()]
		[System.String] $vstsdeploymentgroupname,
		
		[Parameter()]
		[System.String] $vstsdeploymentGroupTags = "mako",

		[Parameter()]
		[System.String] $vstsAgentDirectory = 'c:\vstsagents'

    )
	
	#Import necessary modules
	Import-DscResource -ModuleName VSTSAgent

	Node localhost 
	{	
		xVSTSAgent VSTSAgent {
			Name                = $env:COMPUTERNAME
			ServerUrl           = $vstsServerUrl		
			PATToken            = $vstsPATToken
			collectionname      = $vstscollectionname
			projectname         = $vstsprojectname
			deploymentgroupname = $vstsdeploymentgroupname
			deploymentGroupTags = $vstsdeploymentGroupTags
			AgentDirectory      = $vstsAgentDirectory
			Work                = $vstsWork
			Ensure              = 'Present'
		}
	}

}